# vcpkg-cmake-get-vars

This port contains a helper function to extract CMake variables into the scope of the portfile or other scripts
