# vcpkg-gn

This port contains cmake functions for dealing with a GN buildsystem.

## Example

```cmake
vcpkg_gn_configure(
    SOURCE_PATH "${SOURCE_PATH}"
)
vcpkg_gn_install()
```
