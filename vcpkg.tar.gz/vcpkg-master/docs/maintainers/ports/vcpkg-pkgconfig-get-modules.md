# vcpkg-pkgconfig-get-modules

**Experimental: will change or be removed at any time**

`vcpkg-pkgconfig-get-modules` provides `x_vcpkg_pkgconfig_get_modules()`, a function which simplifies calling
`pkg-config` in portfiles in order to gather dependencies for exotic buildsystems.
