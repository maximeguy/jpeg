# vcpkg_get_windows_sdk

The latest version of this document lives in the [vcpkg repo](https://github.com/Microsoft/vcpkg/blob/master/docs/maintainers/vcpkg_get_windows_sdk.md).

Get the Windows SDK number.

## Usage:
```cmake
vcpkg_get_windows_sdk(<variable>)
```

## Source
[scripts/cmake/vcpkg\_get\_windows\_sdk.cmake](https://github.com/Microsoft/vcpkg/blob/master/scripts/cmake/vcpkg_get_windows_sdk.cmake)
